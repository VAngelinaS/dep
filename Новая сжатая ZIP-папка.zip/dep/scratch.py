import pandas as pd

# Загрузка данных из файлов Excel
file_old = 'C:/Users/Ангелина/Desktop/dep/old_apartments.xlsx'
file_new = 'C:/Users/Ангелина/Desktop/dep/new_apartments.xlsx'

old_apartments = pd.read_excel(file_old)
new_apartments = pd.read_excel(file_new)

# Функция для подбора квартир
def match_apartments(old_df, new_df):
    matched = []
    new_df_sorted = new_df.sort_values(by=['К_Общ', 'К_Жил'], ascending=[True, True])

    for _, old_row in old_df.iterrows():
        suitable_new_apartments = new_df_sorted[
            (new_df_sorted['К_Комн'] == old_row['К_Комн']) &
            (new_df_sorted['К_Общ'] >= old_row['К_Общ']) &
            (new_df_sorted['К_Жил'] >= old_row['К_Жил'])
        ]

        if not suitable_new_apartments.empty:
            best_match = suitable_new_apartments.iloc[0]
            matched.append({
                'Адрес_Короткий_Старый': old_row['Адрес_Короткий'], 'Адрес_Кв_Старый': old_row['Адрес_Кв'],
                'Этаж_Старый': old_row['Этаж'], 'К_Комн_Старый': old_row['К_Комн'],
                'К_Общ_Старый': old_row['К_Общ'], 'К_Жил_Старый': old_row['К_Жил'],
                'Адрес_Короткий_Новый': best_match['Адрес_Короткий'], 'Адрес_Кв_Новый': best_match['Адрес_Кв'],
                'Этаж_Новый': best_match['Этаж'], 'К_Комн_Новый': best_match['К_Комн'],
                'К_Общ_Новый': best_match['К_Общ'], 'К_Жил_Новый': best_match['К_Жил']
            })
            new_df_sorted = new_df_sorted.drop(best_match.name)
        else:
            matched.append({
                'Адрес_Короткий_Старый': old_row['Адрес_Короткий'], 'Адрес_Кв_Старый': old_row['Адрес_Кв'],
                'Этаж_Старый': old_row['Этаж'], 'К_Комн_Старый': old_row['К_Комн'],
                'К_Общ_Старый': old_row['К_Общ'], 'К_Жил_Старый': old_row['К_Жил'],
                'Адрес_Короткий_Новый': None, 'Адрес_Кв_Новый': None,
                'Этаж_Новый': None, 'К_Комн_Новый': None,
                'К_Общ_Новый': None, 'К_Жил_Новый': None
            })

    return pd.DataFrame(matched)

# Выполняем подбор квартир
result = match_apartments(old_apartments, new_apartments)

# Сохранение результата в новый файл Excel
result.to_excel('C:/Users/Ангелина/Desktop/dep/improved_apartments.xlsx', index=False)

print("Сравнение завершено. Результаты сохранены в 'C:/Users/Ангелина/Desktop/dep/improved_apartments.xlsx'.")
